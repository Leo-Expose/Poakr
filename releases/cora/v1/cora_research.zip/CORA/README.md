# CORA research release

This is a new tested research architecture and an EXAMPLE-protocol prototype,
NOT an organizer-compatible submission. No universal win/global novelty claim.

Read research/REPORT.md for final scores and all limitations; research/PROOFS.md
for exactness/certificate derivations; research/REPRODUCE.md for commands.

Standalone candidate: cora_bot_example.py (also research/cora_bot.py).
It needs only standard Python + preinstalled NumPy, no project-package imports,
no runtime table file, and no duplicate-hole inference implementation.

Official variant/protocol/scoring/clock and actual Python 3.11 execution remain
release gates. The raw-net lock defaults OFF unless its game contract is asserted.

Frozen v2 and legacy files are included solely for comparison reproducibility.
The previous v2 delivery remains unchanged.
