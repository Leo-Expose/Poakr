"""Package source/evidence without touching the frozen v2 delivery."""
import json,hashlib,zipfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
HOME=ROOT.parent
confirmation=json.loads((ROOT/'research/confirmation_results.json').read_text())
for name,digest in confirmation['sources'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,('frozen source changed',name)
assert hashlib.sha256((ROOT/'runtime/bot.py').read_bytes()).hexdigest()=='27c303582022e1320e3cad286021c93526c345819567cd6380052c113d522bbb'
standalone=ROOT/'research/cora_bot.py';digest=hashlib.sha256(standalone.read_bytes()).hexdigest()
for row in json.loads((ROOT/'research/resource_results.json').read_text()):assert row['standalone_sha256']==digest
files={}
for directory in ('runtime','engine','legacy','src','bench','research'):
    for p in sorted((ROOT/directory).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.relative_to(ROOT).as_posix()!='research/manifest.json' and p.suffix in ('.py','.json','.md','.log','.jsonl'):
            files[p.relative_to(ROOT).as_posix()]=p.read_bytes()
readme='''# CORA research release

This is a new tested research architecture and an EXAMPLE-protocol prototype,
NOT an organizer-compatible submission. No universal win/global novelty claim.

Read research/REPORT.md for final scores and all limitations; research/PROOFS.md
for exactness/certificate derivations; research/REPRODUCE.md for commands.

Standalone candidate: cora_bot_example.py (also research/cora_bot.py).
It needs only standard Python + preinstalled NumPy, no project-package imports,
no runtime table file, and no duplicate-hole inference implementation.

Official variant/protocol/scoring/clock and actual Python 3.11 execution remain
release gates. The raw-net lock defaults OFF unless its game contract is asserted.

Frozen v2 and legacy files are included solely for comparison reproducibility.
The previous v2 delivery remains unchanged.
'''
files['README.md']=readme.encode();files['cora_bot_example.py']=standalone.read_bytes()
manifest=dict(release='CORA-research-1',date='2026-10-15',official_ready=False,
              standalone_sha256=digest,standalone_bytes=standalone.stat().st_size,
              target_python='3.11',execution_python='3.13.16',python_311_executed=False,
              confirmation_seed=121000,matches_per_mode=48,hands_per_strategic_match=100,
              candidate_duplicate_inference=False,
              current_tests=23,resource_enforcement='OS affinity/AS rlimit; Python audit write/network ban, not full OS container proof',
              frozen_candidate_sources=confirmation['sources'],
              files={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(files.items())})
(ROOT/'research/manifest.json').write_text(json.dumps(manifest,indent=2))
files['research/manifest.json']=(ROOT/'research/manifest.json').read_bytes()
archive=HOME/'cora_research.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo('CORA/'+name,date_time=(2026,10,15,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o644<<16;z.writestr(info,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,data in files.items():assert z.read('CORA/'+name)==data
shutil.copyfile(standalone,HOME/'cora_bot_example.py')
for source,target in [('PROOFS.md','CORA_PROOFS.md'),('REPRODUCE.md','CORA_REPRODUCE.md'),('PROTOCOL_CORA_EXAMPLE.md','CORA_PROTOCOL_EXAMPLE.md')]:
    shutil.copyfile(ROOT/'research'/source,HOME/target)
report=(ROOT/'research/REPORT.md').read_text().replace('](PROOFS.md)','](CORA_PROOFS.md)').replace('](REPRODUCE.md)','](CORA_REPRODUCE.md)').replace('](PROTOCOL_CORA_EXAMPLE.md)','](CORA_PROTOCOL_EXAMPLE.md)')
(HOME/'CORA_REPORT.md').write_text(report)
print(json.dumps(dict(archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(files),standalone_sha256=digest),indent=2))
