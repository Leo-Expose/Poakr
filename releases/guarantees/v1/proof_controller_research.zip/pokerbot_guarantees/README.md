# Proof-aware poker controller research v1

This is an isolated, source-pinned reference overlay, not a complete poker policy
or an organizer-compatible submission. Standard verified synthetic rules only.
Start at docs/guarantees/CONTROLLER.md and IMPLEMENTATION_REPORT.md.

Run from this directory with NumPy and SciPy already installed:

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -m unittest discover -s tests/cora -p 'test_*.py' -v
    python3 tools/cora/settlement_bench.py

This snapshot contains 30 guarantee/controller tests. The broader workspace
reported 53 CORA/guarantee plus 34 v2 tests; the unrelated tests are not included
here. Actual execution used Python 3.13.16; required Python 3.11 is unverified.
There are no runtime installs/network calls. The turn path uses only stdlib;
the cold river proof uses NumPy; the offline toy minimax lab uses SciPy.

Host facts and rules need verification by a real adapter. No universal strict
initial-state victory, official time-bank survival, or tournament claim is made.
The ZIP is immutable; reruns on an extracted copy do not change this archive.
