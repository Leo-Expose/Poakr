# Official integration and guarantee gates

| Gate | Known constraint | Unresolved requirement |
|---|---|---|
| Interpreter/libraries | Target Python 3.11; stdlib, NumPy, SciPy permitted; no runtime installs | Actual 3.11 execution and organizer library versions |
| Resources | 1 vCPU, 1 GB RAM, read-only filesystem, zero network | Exact host image, OS sandbox and enforcement behavior |
| Clock | About 60 cumulative seconds per 400 hands; hard kill/forfeit | Charged intervals, input waiting/startup/teardown, resets, restarts, finals allowance |
| Game | Modified heads-up Hold'em; duplicate deals with swapped seats | Exact deck/ranks/board/hand selection, wagering, fees, stack/payout mechanics |
| Protocol | Autonomous predefined stdin/stdout | Official schema, request IDs, controls, legal amounts, error/lifecycle semantics |
| Match scoring | Win/draw/loss match points | Verify raw-net criterion; any nonlinear/capped primary score |
| Tournament | Swiss six rounds, top 32; finals scores reset, round robin | Exact chip-cap tie-break and ranking/qualification effects |
| Fair play | No copying other teams, collusion, or network | Organizer interpretation of duplicate information; candidate currently does not implement it |
| Team/upload | Exactly two; one team/person; last valid upload counts | Announcement year/date confirmation; actual valid-file submission requirements |

## Certificate-specific gates

**Abandonment:** verify current paid loss bound, all remaining mandatory losses, perpetual legal free abandonment, correct completed scoreboard, and execution without forfeit.

**Capped score:** obtain the actual formula. `sum(clip(hand_net))` is one research contract, not an assumed organizer rule. Raw profit cannot stand in for completed capped score.

**Safe river credit:** verify no more public cards, exact rank/payout semantics, no rake or action/settlement fees, equal initial stack/matching feasibility, standard matched-payout/refund semantics, actual opposing contribution, and a legal check/call continuation. Bind the proof to the current hand/board/holding/rule state. Do not immediately fold a credited current hand.

**Tournament:** a guaranteed current match point can still sacrifice chip tie-break value. No tournament-ranking guarantee follows without the other score/ranking conditions.

## Current evidence does not close these gates

- 47/48 synthetic 100-hand wins is not a guaranteed 400/1000-hand tournament win rate.
- Constrained fixtures pass on Python 3.13.16; grammar checks are not Python 3.11 execution.
- Python audit hooks found no forbidden operations; they are not an OS-level sandbox proof.
- Exact opponent-model arithmetic/quotient does not prove the model describes the true adversary.
- A conditional theorem's flags are assertions to verify, not organizer approval.

Until the specifications are available, work stays in the workspace with EXAMPLE contracts and clearly separated research versions. No official upload has been performed.

**Reference controller:** ledger/binding/payout transitions are implemented and tested separately. Official adapter authentication, accepted-action reconciliation, parser limits, exact clock enforcement and complete-policy integration/holdout remain open. The symbolic turn gate also requires exactly two private cards per player and one future public card under standard high ranking.
