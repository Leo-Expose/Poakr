"""Action-kernel research. Exact blocker correction, public-result model inference.
No actual opponent cards, duplicate-copy knowledge, network or runtime writes.
The parameter family is an approximation; exact enumeration is not exact strategy.
"""
from __future__ import annotations
import math
from itertools import combinations, product
import numpy as np
from runtime.bot import Rules, Evaluator, ValidationError


class RiverKernel:
    """All two-hole hands on a shared final board, with exact disjoint-hand CDFs.

    L(h)=G_< - I_a,< - I_b,<
    T(h)=G_= - I_a,= - I_b,= + 1
    denominator=C(D-board-2,2).
    Scores are evaluated once. Histograms replace the pairwise overlap matrix.
    """
    def __init__(self,board,rules=Rules()):
        if rules.hole_count!=2 or len(board)!=rules.board_count:
            raise ValidationError('river kernel requires two hole cards + final board')
        self.rules=rules; self.board=rules.cards(board)
        available=[c for c in range(rules.deck_size) if c not in self.board]
        if len(available)<4: raise ValidationError('not enough cards')
        self.holes=np.array(list(combinations(available,2)),dtype=np.int64)
        self.index={tuple(h):i for i,h in enumerate(self.holes.tolist())}
        cards=np.empty((len(self.holes),2+len(board)),np.int64)
        cards[:,:2]=self.holes; cards[:,2:]=self.board
        self.scores=Evaluator(rules).score(cards)
        _,group,count=np.unique(self.scores,return_inverse=True,return_counts=True)
        global_lower=np.cumsum(count)-count
        incidence=np.zeros((rules.deck_size,len(count)),np.int32)
        np.add.at(incidence,(self.holes[:,0],group),1)
        np.add.at(incidence,(self.holes[:,1],group),1)
        prefix=np.cumsum(incidence,axis=1)-incidence
        a,b=self.holes.T
        low=global_lower[group]-prefix[a,group]-prefix[b,group]
        tie=count[group]-incidence[a,group]-incidence[b,group]+1
        denominator=math.comb(len(available)-2,2)
        self.percentile=(low+.5*tie)/denominator
        self.work_bytes=self.holes.nbytes+self.scores.nbytes+incidence.nbytes+prefix.nbytes+group.nbytes
        assert np.all((self.percentile>=0)&(self.percentile<=1))
    def view(self,hero):
        hero=tuple(sorted(self.rules.cards(hero)))
        if len(hero)!=2 or hero not in self.index: raise ValidationError('invalid hero hole')
        mask=~np.any(np.isin(self.holes,hero),axis=1)
        ids=np.flatnonzero(mask); own=self.scores[self.index[hero]]
        outcome=np.sign(own-self.scores[ids]) # +1 win, 0 tie, -1 loss
        payoff=(outcome>0).astype(float)+.5*(outcome==0)
        return ids,self.percentile[ids],payoff,outcome


def sigmoid(x): return 1/(1+np.exp(-np.clip(x,-40,40)))


class PolicyMixture:
    """Finite latent policy family; public action/outcome likelihood, not clairvoyance.
    Each hand preserves the parameter/card joint belief until its public end.
    """
    def __init__(self):
        params=np.array(list(product((.50,.65,.80,.90),(0.,.10,.30),(-.10,.05,.22),(0.,.5),(1.,0.))),float)
        self.threshold,self.bluff,self.slack,self.raise_rate,self.value_rate=params.T
        self.weights=np.where(self.value_rate==1,4.,1.); self.weights/=self.weights.sum(); self.hands=0
    def likelihood(self,z,kind,faced,price,can_raise=True):
        z=np.asarray(z)[None,:]
        if not faced:
            bet=self.bluff[:,None]+(1-self.bluff[:,None])*sigmoid((z-self.threshold[:,None])/.035)
            weak_only=self.bluff[:,None]*sigmoid((.45-z)/.05)
            bet=np.where(self.value_rate[:,None]==1,bet,weak_only)
            value=bet if kind=='bet' else 1-bet
        else:
            cont=sigmoid((z-(price+self.slack[:,None]))/.035)
            raised=self.raise_rate[:,None]*sigmoid((z-.82)/.04) if can_raise else 0.
            value=1-cont if kind=='fold' else cont*(raised if kind=='bet' else 1-raised)
        return np.clip(value,.002,.998)
    def begin(self,kernel,hero,compress=True): return HandBelief(self,kernel,hero,compress)


class HandBelief:
    def __init__(self,model,kernel,hero,compress=True):
        self.model=model; self.kernel=kernel
        self.ids,z,payoff,outcome=kernel.view(hero)
        if compress:
            # Exact quotient for this likelihood/payoff family, not approximate
            # card clustering. Counts retain prior mass of merged card pairs.
            keys,count=np.unique(np.column_stack((z,outcome)),axis=0,return_counts=True)
            self.z=keys[:,0]; self.outcome=keys[:,1]
            self.payoff=(self.outcome>0).astype(float)+.5*(self.outcome==0)
            mass=count/len(self.ids)
        else:
            self.z=z;self.payoff=payoff;self.outcome=outcome;mass=np.full(len(self.ids),1/len(self.ids))
        self.joint=model.weights[:,None]*mass[None,:]
        self.evidence=0
    def observe(self,kind,faced,price,can_raise=True):
        self.joint*=self.model.likelihood(self.z,kind,faced,price,can_raise)
        self.joint/=self.joint.sum(); self.evidence+=1
    def equity(self): return float(np.sum(self.joint*self.payoff[None,:]))
    def response(self,price):
        cont=sigmoid((self.z[None,:]-(price+self.model.slack[:,None]))/.035)
        continue_mass=float(np.sum(self.joint*cont))
        win_mass=float(np.sum(self.joint*cont*self.payoff[None,:]))
        return continue_mass,win_mass
    def finish(self,outcome=None):
        if outcome is not None:
            mask=self.outcome==outcome
            if np.any(mask):
                self.joint*=np.where(mask,1.,.002)[None,:]; self.joint/=self.joint.sum()
        if self.evidence:
            marginal=self.joint.sum(axis=1)
            # Explicit contamination floor for nonstationarity/model misspecification.
            self.model.weights=.995*marginal+.005/len(marginal)
            self.model.weights/=self.model.weights.sum(); self.model.hands+=1


class WinLock:
    """Conditional hard certificate for raw cumulative net-chip win scoring.
    Net is COMPLETED-hand own chip profit, not twice that chip difference.
    Remaining includes current hand. Abandonment incurs current committed chips
    plus future forced posting bounds. No optional calls/bets may follow the lock.
    """
    @staticmethod
    def lower_bound(banked_net,current_paid,remaining_hands,max_future_post):
        vals=(banked_net,current_paid,max_future_post)
        if any(not isinstance(x,(int,float)) or not math.isfinite(x) for x in vals):
            raise ValidationError('invalid lock inputs')
        if current_paid<0 or max_future_post<0 or isinstance(remaining_hands,bool) or not isinstance(remaining_hands,int) or remaining_hands<1:
            raise ValidationError('invalid lock bounds')
        return banked_net-current_paid-(remaining_hands-1)*max_future_post
    @classmethod
    def certified(cls,*args): return cls.lower_bound(*args)>1e-9
