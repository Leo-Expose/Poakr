# Pokerbot research workspace

## Latest: OpenSpiel and rigorous win/nonloss objectives

[OpenSpiel assessment and new executable audits](docs/openspiel/ASSESSMENT.md). The framework is useful for offline exploitability research, not a100% strict-win guarantee. Neither optional OpenSpiel module is installed; no OpenSpiel algorithm or full-game solver result is claimed.

New work: an exact six-objective small-game audit,903-pair shared-royal witness against the supplied evaluator, and a privacy-tested simultaneous-discard information contract (not a full adapter). **143 tests pass. Champion unchanged.**

## Working champion: unchanged v1 — red-team update

The first hardening experiment is complete: **96 local matches / 38,400 hands**, with a predeclared fresh holdout. Both versions won all32 holdout fixtures; the challenger earned more chips but failed the weakest-result gate (+7 versus v1's+12). **Not promoted.** These are diagnostic profiles, not tournament odds or a never-losing guarantee.

- [Hardening report, complete results and promotion verdict](docs/discard/ROBUSTNESS_ITERATION_1.md)
- That hardening stage passed129tests; the latest rerun adds14objective/information tests for143total.
- Working champion/upload-shaped artifact remains `releases/discard/v1/`. Experimental research is kept separate under `releases/discard/experimental/` and `releases/discard/experiments/range_guard_v1/`.

## Current: actual Discard Hold’em candidate

The supplied Rulebook, Protocol, 1-November Problem Statement and starter kit define **three starting cards, a simultaneous exposed discard after flop betting, and protocol 1.0**. The earlier two-card CORA/v2 bots are **not compatible with this game** and their historical win rates do not transfer.

Start with:

- [New supplied-engine validation, 2 November](docs/discard/SUPPLIED_ENGINE_VALIDATION.md)
- [Actual-game implementation and measured results](docs/discard/REPORT.md)
- [New pointwise guarantees and precise limits](docs/discard/GUARANTEES.md)
- [PDF reconciliation and original documents](docs/organizer/RULES_RECONCILIATION.md)
- [Current official-release gates](docs/RELEASE_GATES.md)

**New candidate:** `releases/discard/v1/bot.py`; candidate upload-shaped ZIP: `releases/discard/v1/submission.zip`. These are PDF-backed, locally tested candidates, **not organizer-certified submissions**. The Problem Statement and starter-runner checks now pass; actual Python3.11, OS sandbox and final-limit checks remain pending.

### New results

- Earlier supplied-engine validation passed118tests; the latest hardening rerun passes129 (see above).
- **Six supplied-engine full matches**, clocks enabled, zero notices, unchanged candidate. Independent measured request sums:1.195–10.622s in four constrained runs.
- The identical opposing copy **loses212** in a1000-hand mirror. No universal nonloss claim.
- A [clock clarification draft](docs/organizer/CLOCK_CLARIFICATION.md) distinguishes the supplied engine's startup grace from actual measured response time. Not sent to organizers.
- New dead-card turn proof independently checked over **79,464 physical worlds** across two examples; no runtime runout enumeration.
- Four full serialized local fixtures (three 400-hand, one 1000-hand) completed inside the stated limits, with zero illegal replies, accounting errors or forbidden audit attempts.
- A separate **16-hand shove diagnostic loses −229**. No universal initial-state nonloss/victory or tournament dominance claim is made.
- The official tie-break clips **match totals**, not individual hands. The old per-hand clipping theorem remains an abstract lab contract, not the official formula.

## Directory guide

| Directory | Purpose |
|---|---|
| `research/discard_holdem/` | New actual-game protocol, policy, accounting and physical-card proofs |
| `tools/discard/` | Build, independent runner, supplied-engine probes, red-team/comparison tools and packaging |
| `tests/discard/`, `evidence/discard/`, `docs/discard/` | Actual-variant tests, diagnostics and documentation |
| `docs/organizer/`, `vendor/organizer/` | Three supplied PDFs, exact starter code/combined Markdown, provenance and clock clarification |
| `tests/organizer/`, `evidence/organizer_runner/` | New conformance tests, direct CLI logs, measured runs and fresh suite logs |
| `releases/discard/v1/`, `releases/discard/current/` | Frozen candidate/evidence and disposable current builds |
| `research/`, `research/guarantee_lab/` | Preserved CORA and earlier isolated mathematical/controller research |
| `src/`, `runtime/`, `engine/`, `policies/`, `legacy/` | Reusable helpers and preserved earlier bots/evaluators |
| `tools/cora/`, `tools/maintenance/`, `bench/` | Earlier research/reproduction and maintenance tools |
| `tests/cora/`, `tests/test_core.py` | Preserved earlier test suites |
| `data/`, `config/`, `fixtures/` | Earlier assets; EXAMPLE fixtures are not official protocol 1.0 |
| `evidence/cora/`, `evidence/v2/`, `evidence/guarantee_lab/` | Historical measurements and separate reruns |
| `releases/organized/` | Full research workspace bundle; **not** an upload artifact |

## Quick start

Run from this directory with NumPy/SciPy already installed; no runtime installation:

```bash
python3 tools/discard/build.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -m unittest discover -s tests/discard -p 'test_*.py' -v
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 tools/discard/local_runner.py --hands 400 --wire --sandbox --output fresh_local_400.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -m unittest discover -s tests/organizer -v
python3 tools/maintenance/verify_workspace.py
```

The candidate uses stdlib + NumPy. SciPy is only used by the earlier offline toy minimax lab. Local execution is Python **3.13.16**; Python 3.11 grammar is checked, but actual 3.11 execution remains unverified. `--sandbox` denotes affinity/address-space/audit checks, not complete OS sandbox isolation. The earlier self-authored runner is not organizer software; supplied-engine runs are separately documented.

## Preserved history

- CORA corrected confirmation: **47/48 synthetic two-card 100-hand matches**, one loss. [Historical report](docs/cora/REPORT.md); no actual-variant strength implication.
- Frozen executables and ZIPs remain byte-identical. [Layout/preservation](docs/LAYOUT.md) / [migration map](evidence/migration/path_map.json).
- Earlier [guarantee lab](docs/guarantees/README.md), [reference controller](docs/guarantees/CONTROLLER.md), and [implementation report](docs/guarantees/IMPLEMENTATION_REPORT.md) remain separate and source-pinned.

No official upload has been performed. Conditional winning regions, runtime samples, expected policy quality and tournament qualification are different claims.
