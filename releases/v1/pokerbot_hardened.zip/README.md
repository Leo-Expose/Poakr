# Hardened pokerbot prototype

Deployment file: runtime/bot.py (standalone; stdlib + NumPy).
Run: python3 runtime/bot.py

Read VALIDATION.md before submission. Official custom rules and the wire protocol
are NOT yet verified. Local wins do not guarantee competition wins or legality.
The runtime uses Python 3.11-compatible syntax; local tests ran on Python 3.13.

The included benchmarks need only stdlib + NumPy and the included offline engine.
No installation or network access is performed by the bot.
